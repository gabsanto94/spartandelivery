<?php include "php/config.php"; $activePage = "checkin";?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Spartan Delivery</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.js"></script>
    <![endif]-->

    <!--data tables-->
    <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />
    <script type="application/javascript" src="DataTables/datatables.min.js"></script>

    <!--link my style css-->
    <link href="css/myStyle.css" rel="stylesheet">

    <script type="text/javascript" src="js/ajaxOrder.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>

</head>
<body>


<!--nav bar-->
<?php include "php/navbar.php"; ?>

<div class="container-fluid">
    <button type="button" onclick="AddOrderModal()" class="btn btn-primary btn-lg">Add New Item</button><br>
</div>

<div class="panel panel-default">

    <div class="panel-heading">List Entries</div>
    <table id="orders" class="table table-responsive">
        <thead>
            <tr>
                <th>Entry#</th>
                <th>PO#</th>
                <th>To</th>
                <th>Department</th>
                <th>Shipment</th>
                <th>Complete</th>
                <th>Partial</th>
                <th>Quantity</th>
                <th>Signature</th>
                <th>Date</th>
            </tr>
        </thead>

        <tbody>
        <?php

        include "php/dbconnect.php";

        //retrieve data from the database
        $sql = mysqli_query($conn, "SELECT * FROM items");

            //array that holds all the fields
            $rows = mysqli_fetch_assoc($sql);

            if(!$rows){
                echo "No Results.";
            }
            else{

                do{
                    ?>
                        <tr>
                            <td><?php print($rows['id']); ?></td>
                            <td><?php print($rows['PO']); ?></td>
                            <td><?php print($rows['TO1']); ?></td>
                            <td><?php print($rows['department']); ?></td>
                            <td><?php print($rows['shipment']); ?></td>
                            <td><?php print($rows['iscomplete']); ?></td>
                            <td><?php print($rows['partial']); ?></td>
                            <td><?php print($rows['quantity']); ?></td>
                            <td><?php print($rows['signature']); ?></td>
                            <td><?php print($rows['date']); ?></td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">Select<span class="caret"></span></button>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a onclick="UpdateOrderModal('<?php print($rows['id']); ?>','<?php print($rows['PO']); ?>',
                                                                         '<?php print($rows['TO1']); ?>', '<?php print($rows['shipment']); ?>',
                                                                         '<?php print($rows['iscomplete']); ?>', '<?php print($rows['partial']); ?>',
                                                                         '<?php print($rows['quantity']); ?>', '<?php print($rows['signature']); ?>',
                                                                         '<?php print($rows['date']); ?>'   );">Edit</a></li>
                                        <li><a onclick="DeleteItem('<?php print($rows['id']); ?>');">Delete</a></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php
                } while($rows = mysqli_fetch_assoc($sql));

            }

            mysqli_free_result($sql);
                ?>
        </tbody>
    </table>
</div>

<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close btn-danger" data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title">Add New</h4>
            </div>

            <!--action="php/addItem.php" method="POST"-->
            <form role="form" name="frmItems" action="" onsubmit="AddItem(myId, action1); return false;" method="POST">

                <!--
                    PO, TO, Shipment, Complete, Partial, Qty, Signature, and date
                -->

                <div class="col-lg-12">
                    <!--TODO: make it drop down and the years-->
                    <div class="form-group">
                        <label>Fiscal Year: </label> <input name="fiscal" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>PO #</label> <input name="po" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="TO1">Select Teacher </label>
                        <select class="form-control" id="TO1" required>
                            <?php

                                //make query to get all names of staff and display them in the dropdown option list
                                $sql1 = mysqli_query($conn, "SELECT name FROM staff");

                                //hold values in array
                                $rows1 = mysqli_fetch_assoc($sql1);

                                if(!rows1){
                                    echo "no rows for staff";
                                }
                                else{
                                    do{
                                       echo "<option>".$rows1['name']."</option>";

                                    }while($rows1 = mysqli_fetch_assoc($sql1));
                                }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="department">Select Department </label>
                        <select class="form-control" id="department" required>
                            <option>Administration</option>
                            <option>Athletics</option>
                            <option>Bookstore</option>
                            <option>Copy Paper</option>
                            <option>ESS</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Shipment</label><input name="shipment" class="form-control">
                    </div>

                    <!--TODO: fix the style of the form-->
                    <div class="form-group">
                            Complete:
                            <label class="radio-inline">
                            <input type="radio" name="optionComplete1">Yes</label>
                            <label class="radio-inline">
                            <input type="radio" name="optionComplete1">No</label>
                        / Partial:
                        <label class="radio-inline">
                            <input type="radio" name="optpartial1">Yes</label>
                        <label class="radio-inline">
                            <input type="radio" name="optpartial1">No</label>
                    </div>

                    <div class="form-group">
                        <label>Quantity</label> <input name="qty" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>Signature</label> <input name="signature1" class="form-control">
                    </div>

                    <!--TODO: add button that returns todays date-->
                    <div class="form-group">
                        <label>date</label> <input name="date1" class="form-control" required>
                    </div>

                    <button type="submit" class="btn btn-info btn-lg pull-right">
                        <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Add Item
                    </button>


                </div>
            </form>

            <div class="modal-footer">
                <button type="button" class="btn btn-danger btn-circle" data-dismiss="modal"><i class="fa fa-times"></i></button>
            </div>
        </div>
    </div>


</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>

<!--modal script-->
<script type="text/javascript">

    var action1;
    var myId;

    function AddOrderModal()
    {
        //new Action
        action1 = 'NEW';

        //clearing previous values
        document.frmItems.po.value = "";
        //document.frmItems.to1.value = "";
        document.frmItems.shipment.value = "";
        //document.frmItems.complete1.value = "";
        //document.frmItems.partial1.value = "";
        document.frmItems.qty.value = "";
        document.frmItems.signature1.value = "";
        document.frmItems.date1.value = "";

        $('#modal').modal('show');
    }

    function UpdateOrderModal(id, po, to1, shipment, isComplete, isPartial, quantity, signature, date)
    {
        //have our EDIT Action
        action1 = 'EDIT';
        myId = id;

        //find the field in the document and then supply the value
        document.frmItems.po.value = po;
        //document.frmItems.to1.value = to1;
        document.frmItems.shipment.value = shipment;
        //document.frmItems.complete1.value = isComplete;
        //document.frmItems.partial1.value = isPartial;
        document.frmItems.qty.value = quantity;
        document.frmItems.signature1.value = signature;
        document.frmItems.date1.value = date;

        $('#modal').modal('show');
    }

</script>


</body>
</html>