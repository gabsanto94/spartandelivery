<?php include "php/config.php"; $activePage = "settings";?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Spartan Delivery</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.js"></script>
    <![endif]-->

    <!--data tables-->
    <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />
    <script type="application/javascript" src="DataTables/datatables.min.js"></script>

    <!--link my style css-->
    <link href="css/myStyle.css" rel="stylesheet">

    <script type="text/javascript" src="js/ajaxOrder.js"></script>

</head>
<body>


<!--nav bar-->
<?php include "php/navbar.php"; ?>

<div class="container-fluid">
    <!--TODO: add modals departments and openPO-->
    <button type="button" onclick="AddStaffModal()" class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-user"></span>Add New Staff Member</button>
</div>

<div class="panel panel-collapse">

    <div class="panel-heading">List of Staff Members</div>
    <table id="orders" class="table table-responsive">
        <thead>
        <tr>
            <th>Entry#</th>
            <th>Staff Name</th>
        </tr>
        </thead>

        <tbody>
        <?php

        include "php/dbconnect.php";

        //retrieve data from the database
        $sql = mysqli_query($conn, "SELECT * FROM staff");

        //array that holds all the fields
        $rows = mysqli_fetch_assoc($sql);

        if(!$rows){
            echo "No Results.";
        }
        else{

            do{
                ?>
                <tr>
                    <td><?php print($rows['id']); ?></td>
                    <td><?php print($rows['name']); ?></td>
                    <td>
                        <div class="btn-group">
                            <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">Select <span class="caret"></span></button>
                            <ul class="dropdown-menu" role="menu">
                                <li><a onclick="UpdateStaffName('<?php print($rows['id']); ?>','<?php print($rows['name']); ?>');">Edit</a></li>
                                <li><a onclick="DeleteStaff('<?php print($rows['id']); ?>');">Delete</a></li>
                            </ul>
                        </div>
                    </td>
                </tr>
                <?php
            } while($rows = mysqli_fetch_assoc($sql));

        }

        mysqli_free_result($sql);
        ?>
        </tbody>
    </table>
</div>

<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close btn-danger" data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title">Add New Staff Member</h4>
            </div>

            <form role="form" name="frmItems" action="" onsubmit="AddStaff(myId, action1); return false;" method="POST">

                <!--
                    Name of staff
                -->

                <div class="col-lg-12">
                    <div class="form-group">
                        <label>Name</label> <input name="name" class="form-control" required>
                    </div>

                    <button type="submit" class="btn btn-info btn-lg pull-right">
                        <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Add Staff
                    </button>
                </div>

                <div class="modal-footer">
                    <span class="glyphicon glyphicon-eye-close"></span>
                </div>
            </form>
        </div>
    </div>


</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>

<!--modal script-->
<script type="text/javascript">

    var action1;
    var myId;

    function AddStaffModal()
    {
        //new Action
        action1 = 'new_staff';

        //clearing previous values
        document.frmItems.name.value = "";

        $('#modal').modal('show');
    }

    function UpdateStaffName(id, name)
    {
        //have our EDIT Action
        action1 = 'update_staff';
        myId = id;

        //find the field in the document and then supply the value
        document.frmItems.name.value = name;

        $('#modal').modal('show');
    }

</script>


</body>
</html>