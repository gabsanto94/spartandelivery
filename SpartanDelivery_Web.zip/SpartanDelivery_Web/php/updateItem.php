<?php
/**
 * Created by PhpStorm.
 * User: santos
 * Date: 5/19/17
 * Time: 9:16 PM
 */

    //require the connection to database
    include "dbconnect.php";

    $id = $_POST['myId'];
    $po = $_POST['po'];
    $to = $_POST['to1'];
    $shipment = $_POST['shipment'];
    $complete = $_POST['complete1'];
    $partial = $_POST['partial1'];
    $qty = $_POST['qty'];
    $signature = $_POST['signature1'];
    $date = $_POST['date1'];

    //update the database
    $sql = "UPDATE items SET PO='$po', TO1='$to', shipment='$shipment', iscomplete='$complete', partial='$partial', quantity='$qty', signature='$signature', date='$date' WHERE id='$id'";

    if(mysqli_query($conn, $sql))
    {
        echo "Successfully Updated Database!<br>";
    }
    else
    {
        echo "Error Updating Database!";

    }

        mysqli_close($conn);