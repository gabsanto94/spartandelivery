<?php

//require the connection to database
include "dbconnect.php";

$id = $_POST['myId'];
$name = $_POST['name'];

//update the database
$sql = "UPDATE staff SET name='$name' WHERE id='$id'";

if(mysqli_query($conn, $sql))
{
    echo "Successfully Updated Database!<br>";
}
else
{
    echo "Error Updating Database!";

}

mysqli_close($conn);