<?php

//require the connection to database
include "dbconnect.php";

$name = $_POST['name'];

//create the query to insert data
//INSERT INTO table_name (no QUOATIONS) VALUES (inQUOTATIONS)
$sql = "INSERT INTO staff (name) VALUES ('$name')";

if(mysqli_query($conn, $sql))
{
    echo "Successfully Entered Into Database!<br>";
}
else
{
    echo "Error Inserting Data!";

}

mysqli_close($conn);