<?php

    //require the connection to database
    include "dbconnect.php";

    $po = $_POST['po'];
    $to = $_POST['to1'];
    $shipment = $_POST['shipment'];
    $complete = $_POST['complete1'];
    $partial = $_POST['partial1'];
    $qty = $_POST['qty'];
    $signature = $_POST['signature1'];
    $date = $_POST['date1'];

    //create the query to insert data
    //INSERT INTO table_name (no QUOATIONS) VALUES (inQUOTATIONS)
    $sql = "INSERT INTO items (PO, TO1, shipment, iscomplete, partial, quantity, signature, date) VALUES ('$po','$to','$shipment','$complete','$partial','$qty','$signature','$date')";

    if(mysqli_query($conn, $sql))
    {
        echo "Successfully Entered Into Database!<br>";
    }
    else
        {
            echo "Error Inserting Data!";

        }

        mysqli_close($conn);