<?php

//require the connection to database
include "dbconnect.php";

$id = $_POST['myId'];

//update the database
$sql = "DELETE FROM staff WHERE id='$id'";

if(mysqli_query($conn, $sql))
{
    echo "Successfully Delete Staff From Database!<br>";
}
else
{
    echo "Error Deleting Row From Database!";

}

mysqli_close($conn);